const LocationCity = () => {
  return <div>Ghaziabad</div>;
};

export default LocationCity;
